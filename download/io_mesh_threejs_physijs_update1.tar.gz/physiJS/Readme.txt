io_mesh_threejs folder goes into:

C:\Users\User\AppData\Roaming\Blender Foundation\Blender\2.69\scripts\addons

PhysicsSceneLoader.js goes into game directory and called with <script> tag.
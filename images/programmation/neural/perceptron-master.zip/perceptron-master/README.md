# How to build
Just intall opencl on your system, and build using cmake:

cd build
cmake ..
make

# Perceptron

This program creates a perceptron using OpenCL.
See main.cpp for an example of how to use the Perceptron class.
Everything is well documented, so for now, just browse through the source code to figure out how it works.

More details to come.


